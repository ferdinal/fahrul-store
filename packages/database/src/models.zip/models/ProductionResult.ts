import mongoose, { Schema, type InferSchemaType, type Model } from 'mongoose';

const productionResultAllocationSchema = new Schema(
  {
    inputLot: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionLot',
      required: true,
    },
    quantityProcessed: {
      type: Number,
      required: true,
      min: 1,
    },
    goodQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    scrapQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    // Lot output untuk unit yang lolos proses.
    goodLot: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionLot',
      default: null,
    },
    // Lot output untuk unit scrap; tidak boleh diteruskan.
    scrapLot: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionLot',
      default: null,
    },
  },
  { _id: true },
);

const productionResultSchema = new Schema(
  {
    productionOrder: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionOrder',
      required: true,
      index: true,
    },
    // ID step dari array steps milik Production Order.
    stepId: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    sequence: {
      type: Number,
      required: true,
      min: 1,
    },
    process: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionProcess',
      required: true,
    },
    operator: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    inspectedQuantity: {
      type: Number,
      required: true,
      min: 1,
    },
    goodQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    scrapQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    processedRanges: {
      type: [
        {
          start: { type: Number, required: true, min: 1 },
          end: { type: Number, required: true, min: 1 },
        },
      ],
      required: true,
    },
    goodRanges: {
      type: [
        {
          start: { type: Number, required: true, min: 1 },
          end: { type: Number, required: true, min: 1 },
        },
      ],
      required: true,
      default: [],
    },
    scrapRanges: {
      type: [
        {
          start: { type: Number, required: true, min: 1 },
          end: { type: Number, required: true, min: 1 },
        },
      ],
      required: true,
      default: [],
    },
    allocations: {
      type: [productionResultAllocationSchema],
      required: true,
      validate: {
        validator: (
          allocations: Array<{
            quantityProcessed: number;
            goodQuantity: number;
            scrapQuantity: number;
          }>,
        ) => allocations.length > 0,
        message: 'Minimal harus ada satu alokasi lot.',
      },
    },
    notes: {
      type: String,
      trim: true,
      default: '',
    },
    recordedAt: {
      type: Date,
      required: true,
      default: Date.now,
    },
    // Mencegah request yang sama tercatat dua kali saat retry.
    idempotencyKey: {
      type: String,
      required: true,
      trim: true,
    },
  },
  { timestamps: true },
);

// Satu key hanya boleh digunakan sekali untuk pencatatan hasil.
productionResultSchema.index({ idempotencyKey: 1 }, { unique: true });

productionResultSchema.index({
  productionOrder: 1,
  stepId: 1,
  recordedAt: -1,
});

// Validasi konsistensi total hasil dengan detail alokasi.
productionResultSchema.pre('validate', function () {
  const allocations = this.allocations ?? [];

  const allocationProcessed = allocations.reduce(
    (total, item) => total + item.quantityProcessed,
    0,
  );
  const allocationGood = allocations.reduce(
    (total, item) => total + item.goodQuantity,
    0,
  );
  const allocationScrap = allocations.reduce(
    (total, item) => total + item.scrapQuantity,
    0,
  );

  if (
    allocations.some(
      (item) =>
        !Number.isInteger(item.quantityProcessed) ||
        !Number.isInteger(item.goodQuantity) ||
        !Number.isInteger(item.scrapQuantity) ||
        item.quantityProcessed < 1 ||
        item.goodQuantity < 0 ||
        item.scrapQuantity < 0 ||
        item.goodQuantity + item.scrapQuantity !== item.quantityProcessed,
    )
  ) {
    this.invalidate(
      'allocations',
      'Setiap alokasi harus memenuhi goodQuantity + scrapQuantity = quantityProcessed.',
    );
  }

  if (
    allocationProcessed !== this.inspectedQuantity ||
    allocationGood !== this.goodQuantity ||
    allocationScrap !== this.scrapQuantity
  ) {
    this.invalidate(
      'allocations',
      'Total alokasi harus sama dengan total hasil inspeksi.',
    );
  }

  if (
    !Number.isInteger(this.inspectedQuantity) ||
    !Number.isInteger(this.goodQuantity) ||
    !Number.isInteger(this.scrapQuantity) ||
    this.inspectedQuantity < 1 ||
    this.goodQuantity < 0 ||
    this.scrapQuantity < 0 ||
    this.goodQuantity + this.scrapQuantity !== this.inspectedQuantity
  ) {
    this.invalidate(
      'inspectedQuantity',
      'Hasil inspeksi harus berupa bilangan bulat dan good + scrap harus sama dengan inspected.',
    );
  }
});

export type ProductionResult = InferSchemaType<typeof productionResultSchema>;

export const ProductionResultModel: Model<ProductionResult> =
  (mongoose.models.ProductionResult as Model<ProductionResult> | undefined) ??
  mongoose.model<ProductionResult>('ProductionResult', productionResultSchema);
