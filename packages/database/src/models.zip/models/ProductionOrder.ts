import mongoose, { Schema, type InferSchemaType, type Model } from 'mongoose';

const productionStepSchema = new Schema(
  {
    process: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionProcess',
      required: true,
    },

    processName: {
      type: String,
      required: true,
      trim: true,
    },

    processCode: {
      type: String,
      required: true,
      trim: true,
    },

    sequence: {
      type: Number,
      required: true,
      min: 1,
    },

    // Referensi ke _id step lain dalam Production Order yang sama.
    dependsOn: {
      type: [
        {
          type: Schema.Types.ObjectId,
        },
      ],
      default: [],
    },

    status: {
      type: String,
      enum: [
        'planned',
        'in_progress',
        'partially_completed',
        'completed',
        'cancelled',
      ],
      default: 'planned',
    },

    // Ringkasan kuantitas yang sudah diperiksa pada proses ini.
    quantityProcessed: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    quantityGood: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    quantityScrap: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    startedAt: {
      type: Date,
      default: null,
    },

    completedAt: {
      type: Date,
      default: null,
    },

    notes: {
      type: String,
      trim: true,
      default: '',
    },
  },
  { _id: true },
);

const productionOrderSchema = new Schema(
  {
    orderNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    batch: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionBatch',
      required: true,
    },

    product: {
      type: Schema.Types.ObjectId,
      ref: 'Product',
      required: true,
    },

    quantity: {
      type: Number,
      required: true,
      min: 1,
    },

    status: {
      type: String,
      enum: ['planned', 'in_progress', 'completed', 'cancelled'],
      default: 'planned',
    },

    // Diisi berdasarkan hasil aktual setelah seluruh proses wajib selesai.
    finalGoodQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    // Selisih target dengan hasil akhir barang jadi.
    shortfallQuantity: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    steps: {
      type: [productionStepSchema],
      default: [],
    },

    notes: {
      type: String,
      trim: true,
      default: '',
    },
  },
  { timestamps: true },
);

export type ProductionStep = InferSchemaType<typeof productionStepSchema>;

export type ProductionOrder = InferSchemaType<typeof productionOrderSchema>;

export const ProductionOrderModel: Model<ProductionOrder> =
  (mongoose.models.ProductionOrder as Model<ProductionOrder> | undefined) ??
  mongoose.model<ProductionOrder>('ProductionOrder', productionOrderSchema);
