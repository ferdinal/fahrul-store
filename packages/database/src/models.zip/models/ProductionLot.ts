import mongoose, { Schema, type InferSchemaType, type Model } from 'mongoose';

const productionLotSchema = new Schema(
  {
    productionOrder: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionOrder',
      required: true,
      index: true,
    },
    product: {
      type: Schema.Types.ObjectId,
      ref: 'Product',
      required: true,
    },
    lotCode: {
      type: String,
      required: true,
      trim: true,
    },
    // Lot induk jika lot ini merupakan hasil pemecahan lot lain.
    parentLot: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionLot',
      default: null,
    },
    // Step asal pada Production Order. Step merupakan subdokumen.
    sourceStepId: {
      type: Schema.Types.ObjectId,
      default: null,
    },
    sourceResult: {
      type: Schema.Types.ObjectId,
      ref: 'ProductionResult',
      default: null,
    },
    // Jumlah unit fisik yang diwakili lot ini.
    quantity: {
      type: Number,
      required: true,
      min: 1,
      validate: {
        validator: (value: number) => Number.isInteger(value) && value >= 1,
        message: 'Quantity lot harus berupa bilangan bulat positif.',
      },
    },
    status: {
      type: String,
      enum: ['active', 'scrap', 'finished'],
      default: 'active',
      required: true,
    },
    unitRanges: {
      type: [
        {
          start: { type: Number, required: true, min: 1 },
          end: { type: Number, required: true, min: 1 },
        },
      ],
      required: true,
      default: [],
    },
    notes: {
      type: String,
      trim: true,
      default: '',
    },
  },
  { timestamps: true },
);

// Kode lot unik dalam satu Production Order.
productionLotSchema.index({ productionOrder: 1, lotCode: 1 }, { unique: true });

productionLotSchema.index({
  productionOrder: 1,
  status: 1,
});

export type ProductionLot = InferSchemaType<typeof productionLotSchema>;

export const ProductionLotModel: Model<ProductionLot> =
  (mongoose.models.ProductionLot as Model<ProductionLot> | undefined) ??
  mongoose.model<ProductionLot>('ProductionLot', productionLotSchema);
